# Plan de Stockage et de Sécurité des Données

## 1. Où sont rangées les données ?
- **Environnement de développement** : Google Colab (espace temporaire, isolé par équipe).
- **Espace de livraison** : Plateforme `equation.africadataentry.com` (dossier `02_nettoyage` et `03_transformation`).
- **Format** : Fichiers CSV (UTF-8) pour l'interopérabilité et PNG pour les schémas d'architecture.

## 2. Comment les données circulent-elles ? (Data Pipeline)
1. **Ingestion** : Le fichier Excel source (DGESS) est lu et nettoyé.
2. **Structuration** : Les données sont éclatées en 8 tables (format Tidy Data).
3. **Consolidation** : Création de la table maîtresse `region-indicateurs`.
4. **Restitution** : Le tableau de bord lit la table maîtresse pour afficher la carte des risques.

## 3. Qui y accède ? (Gestion des rôles - RBAC)
- **Data Engineer** : Accès en écriture (création et nettoyage des fichiers).
- **Data Architect** : Accès en lecture/écriture (définition des schémas et métadonnées).
- **Data Analyst / Scientist** : Accès en lecture (pour le calcul de l'IRD).
- **Décideurs (Directeurs Régionaux)** : Accès en lecture seule (via le Dashboard final).
- **Jury du Challenge** : Accès en lecture (audit de reproductibilité).

## 4. Protections et Éthique
- **Anonymat** : Aucune donnée nominative. Les analyses sont agrégées par région.
- **Traçabilité** : Chaque fichier est versionné (v1) et documenté par un dictionnaire.
- **Confidentialité** : Les données ne sont traitées que pour les besoins du concours.
