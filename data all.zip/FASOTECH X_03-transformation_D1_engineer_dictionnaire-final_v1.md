# Dictionnaire — Table d'indicateurs régionaux (ÉCOLE VIGILANTE)

Cette table est le livrable final du Data Engineer pour le Data Analyst.
Elle contient une ligne par région du Burkina Faso et les 6 indicateurs clés pour l'analyse du décrochage.

| Variable | Type | Unité | Source | Définition |
|---|---|---|---|---|
| region | texte | — | DGESS | Nom de la région (13 régions) |
| taux_achevement_2025 | float | % | Feuil8 | Taux d'achèvement au primaire (moyenne G/F) |
| variation_tbs_5ans | float | ratio | Feuil7 | (TBS 2025 − TBS 2020) / TBS 2020 (moyenne G/F) |
| perte_ecoles | float | ratio | Feuil13 | (Écoles 2025 − Écoles 2016) / Écoles 2016 (Somme Public+Privé) |
| part_rurale | float | ratio | Feuil3 | Effectif rural 2025 / Effectif total 2025 |
| tbs_prescolaire_2025 | float | % | Préscolaire T5 | TBS préscolaire 2025 (moyenne G/F) |
| evolution_inscrits_cp1 | float | ratio | Feuil5 | (Inscrits CP1 2025 − CP1 2020) / CP1 2020 (Somme G+F) |

**Note :** Les valeurs manquantes ont été éliminées. Les données sont prêtes pour la normalisation (min-max) par le Data Analyst.
